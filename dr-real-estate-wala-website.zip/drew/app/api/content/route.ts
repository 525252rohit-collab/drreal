import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
import { load, save, mode } from "@/lib/content";
export const dynamic = "force-dynamic";
export async function GET() { if (!isAdmin()) return NextResponse.json({ error: "Unauthorized" }, { status: 401 }); return NextResponse.json({ store: await load(), mode: mode(), ai: !!process.env.ANTHROPIC_API_KEY }); }
export async function PUT(r: Request) {
  if (!isAdmin()) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { action, draft } = await r.json(); const s = await load();
  try {
    if (action === "save") s.draft = draft;
    else if (action === "publish") { s.draft = draft; s.previous = s.published; s.published = draft; }
    else if (action === "revert") { if (!s.previous) return NextResponse.json({ error: "No previous version yet." }, { status: 400 }); s.published = s.previous; s.draft = s.previous; }
    await save(s);
  } catch (e: any) { return NextResponse.json({ error: "Save failed: " + e.message }, { status: 500 }); }
  return NextResponse.json({ store: s });
}
