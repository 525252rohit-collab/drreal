import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
import { upload } from "@/lib/content";
export async function POST(r: Request) {
  if (!isAdmin()) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const f = (await r.formData()).get("file") as File;
  if (!f || !f.type.startsWith("image/") || f.size > 8e6) return NextResponse.json({ error: "Upload an image under 8 MB." }, { status: 400 });
  try { return NextResponse.json({ url: await upload(f.name, Buffer.from(await f.arrayBuffer()), f.type) }); } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }); }
}
