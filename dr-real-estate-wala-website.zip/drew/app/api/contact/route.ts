import { NextResponse } from "next/server";
export async function POST(r: Request) {
  const b = await r.json();
  if (!b.name || !/^[+\d\s-]{10,15}$/.test(b.mobile || "") || (b.email && !/^\S+@\S+\.\S+$/.test(b.email))) return NextResponse.json({ error: "Check your name, mobile number and email." }, { status: 400 });
  const hook = process.env.FORM_WEBHOOK_URL; // e.g. a Formspree endpoint that emails you
  if (!hook) return NextResponse.json({ error: "Form delivery is not set up yet. Please use WhatsApp or call." }, { status: 501 });
  const res = await fetch(hook, { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(b) });
  return res.ok ? NextResponse.json({ ok: true }) : NextResponse.json({ error: "Could not send. Please try WhatsApp." }, { status: 502 });
}
