import { NextResponse } from "next/server";
import { isAdmin } from "@/lib/auth";
export async function POST(r: Request) {
  if (!isAdmin()) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return NextResponse.json({ error: "AI editing is not configured. Add ANTHROPIC_API_KEY on the server, or edit manually in the Content tab." }, { status: 501 });
  const { instruction, draft } = await r.json();
  const res = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" }, body: JSON.stringify({ model: process.env.AI_MODEL || "claude-sonnet-4-6", max_tokens: 16000, system: "You edit a website's JSON content. Apply the instruction and return ONLY the complete updated JSON, same shape {site, sections}. Section types: hero, about, timeline, drew, cards, mission, testimonials, gallery, contact; new text sections can reuse 'about' (heading, intro[], facts[]). Never invent achievements, testimonials, dates or financial results; use [placeholder] text. Leave image fields unchanged (images are uploaded manually). Background colour changes are not supported in content; leave unchanged.", messages: [{ role: "user", content: `Instruction: ${instruction}\n\nCurrent JSON:\n${JSON.stringify(draft)}` }] }) });
  if (!res.ok) return NextResponse.json({ error: "AI request failed: " + (await res.text()).slice(0, 200) }, { status: 502 });
  try { const t = (await res.json()).content[0].text; return NextResponse.json({ draft: JSON.parse(t.slice(t.indexOf("{"), t.lastIndexOf("}") + 1)) }); } catch { return NextResponse.json({ error: "AI returned an unreadable result. Nothing was changed." }, { status: 502 }); }
}
