import "./globals.css";
import { Fraunces, Hind } from "next/font/google";
import { load } from "@/lib/content";
const serif = Fraunces({ subsets: ["latin"], variable: "--f-serif" });
const sans = Hind({ subsets: ["latin", "devanagari"], weight: ["400", "500", "600"], variable: "--f-sans" });
export async function generateMetadata() { const s = (await load()).published.site; return { title: s.title, description: s.description }; }
export default function L({ children }: { children: React.ReactNode }) { return <html lang="en"><body className={`${serif.variable} ${sans.variable}`}>{children}</body></html>; }
