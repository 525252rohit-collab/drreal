"use client";
import { useEffect, useState } from "react";
import Site from "@/components/Site";
import type { Content, Store } from "@/lib/content";

const isImg = (k: string) => /image|photo|portrait|logo/i.test(k);
function Field({ k, v, set }: { k: string; v: any; set: (n: any) => void }) {
  if (Array.isArray(v)) return <div className="ml-2 pl-3 border-l-2 border-gold/50 space-y-2"><p className="font-semibold text-sm">{k}</p>
    {v.map((it, i) => <div key={i} className="bg-white border rounded p-2 space-y-2"><Field k={`#${i + 1}`} v={it} set={n => set(v.map((x, j) => (j === i ? n : x)))} /><button className="text-xs text-burgundy" onClick={() => set(v.filter((_, j) => j !== i))}>Remove</button></div>)}
    <button className="text-sm underline" onClick={() => set([...v, v[0] && typeof v[0] === "object" ? Object.fromEntries(Object.keys(v[0]).map(x => [x, ""])) : ""])}>+ Add item</button></div>;
  if (v && typeof v === "object") return <div className="space-y-2">{Object.entries(v).map(([kk, vv]) => <Field key={kk} k={kk} v={vv} set={n => set({ ...v, [kk]: n })} />)}</div>;
  if (isImg(k) || (k === "" )) return <ImgField k={k} v={v} set={set} />;
  const long = typeof v === "string" && v.length > 70;
  return <label className="block text-sm"><span className="font-semibold">{k}</span>{long ? <textarea className="inp mt-1" rows={3} value={v} onChange={e => set(e.target.value)} /> : <input className="inp mt-1" value={v ?? ""} onChange={e => set(e.target.value)} />}</label>;
}
function ImgField({ k, v, set }: { k: string; v: string; set: (n: string) => void }) {
  const [err, setErr] = useState("");
  async function up(f?: File) { if (!f) return; const fd = new FormData(); fd.append("file", f); const r = await fetch("/api/upload", { method: "POST", body: fd }); const j = await r.json(); r.ok ? set(j.url) : setErr(j.error); }
  return <div className="text-sm"><span className="font-semibold">{k}</span><div className="flex items-center gap-2 mt-1">{v && /* eslint-disable-next-line @next/next/no-img-element */ <img src={v} alt="" className="h-12 w-12 object-cover rounded" />}<input className="inp" value={v ?? ""} onChange={e => set(e.target.value)} placeholder="Image URL or upload" /><input type="file" accept="image/*" aria-label={`Upload ${k}`} onChange={e => up(e.target.files?.[0])} /></div>{err && <p className="text-burgundy">{err}</p>}</div>;
}

export default function Admin() {
  const [authed, setAuthed] = useState<boolean | null>(null); const [pw, setPw] = useState("");
  const [store, setStore] = useState<Store | null>(null); const [draft, setDraft] = useState<Content | null>(null);
  const [info, setInfo] = useState({ mode: "", ai: false }); const [msg, setMsg] = useState(""); const [tab, setTab] = useState("content"); const [sel, setSel] = useState("site");
  const [instr, setInstr] = useState(""); const [busy, setBusy] = useState(false);
  const loadAll = async () => { const r = await fetch("/api/content"); if (!r.ok) return setAuthed(false); const j = await r.json(); setStore(j.store); setDraft(j.store.draft); setInfo({ mode: j.mode, ai: j.ai }); setAuthed(true); };
  useEffect(() => { loadAll(); }, []);
  async function login() { const r = await fetch("/api/login", { method: "POST", body: JSON.stringify({ password: pw }) }); if (r.ok) loadAll(); else setMsg((await r.json()).error); }
  async function act(action: string) { const r = await fetch("/api/content", { method: "PUT", body: JSON.stringify({ action, draft }) }); const j = await r.json(); if (!r.ok) return setMsg(j.error); setStore(j.store); setDraft(j.store.draft); setMsg(action === "save" ? "Draft saved." : action === "publish" ? "Published. The live website is updated." : "Reverted to the previous published version."); }
  async function ai() { setBusy(true); const r = await fetch("/api/ai", { method: "POST", body: JSON.stringify({ instruction: instr, draft }) }); const j = await r.json(); setBusy(false); if (!r.ok) return setMsg(j.error); setDraft(j.draft); setTab("preview"); setMsg("AI changes applied to the draft. Check the preview, then Publish."); }
  if (authed === null) return <p className="p-8">Loading…</p>;
  if (!authed) return <main className="min-h-screen grid place-items-center bg-ghost p-5"><form className="card w-full max-w-sm space-y-3" onSubmit={e => { e.preventDefault(); login(); }}><h1 className="font-serif text-2xl text-navy">Admin login</h1><label className="block">Password<input type="password" className="inp" value={pw} onChange={e => setPw(e.target.value)} /></label><button className="btn bg-burgundy text-white w-full">Log in</button>{msg && <p className="text-burgundy" role="alert">{msg}</p>}</form></main>;
  const d = draft!; const upd = (n: Content) => setDraft(n); const secIdx = d.sections.findIndex(x => x.id === sel);
  const move = (i: number, dir: number) => { const a = [...d.sections]; const j = i + dir; if (j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; upd({ ...d, sections: a }); };
  return <div className="min-h-screen bg-paper">
    <div className="sticky top-0 z-50 bg-navy text-white px-4 py-3 flex flex-wrap items-center gap-2"><b className="font-serif mr-auto">Edit Website</b>
      <span className="text-xs bg-white/20 rounded px-2 py-1">{info.mode === "supabase" ? "Saving to Supabase (permanent)" : "DEMO MODE: not permanent on hosting. Connect Supabase."}</span>
      {["content", "sections", "ai", "preview"].map(t => <button key={t} onClick={() => setTab(t)} className={`btn !py-1 text-sm ${tab === t ? "bg-gold text-navy" : "bg-white/10"}`}>{{ content: "Content", sections: "Sections", ai: "AI Website Editor", preview: "Live Preview" }[t]}</button>)}
      <button className="btn !py-1 text-sm bg-white/10" onClick={() => act("save")}>Save Changes</button><button className="btn !py-1 text-sm bg-burgundy" onClick={() => act("publish")}>Publish Website</button><button className="btn !py-1 text-sm bg-white/10" onClick={() => confirm("Go back to the previous published version?") && act("revert")}>Reset to Previous Version</button></div>
    {msg && <p role="status" className="bg-gold/20 px-4 py-2 text-sm">{msg}</p>}
    {tab === "content" && <div className="max-w-6xl mx-auto p-4 grid md:grid-cols-[14rem_1fr] gap-6"><nav className="space-y-1" aria-label="Sections">{[{ id: "site", nav: "Site, contact & images" }, ...d.sections.map(x => ({ id: x.id, nav: x.id }))].map(x => <button key={x.id} onClick={() => setSel(x.id)} className={`block w-full text-left px-3 py-2 rounded ${sel === x.id ? "bg-burgundy text-white" : "bg-white border"}`}>{x.nav}</button>)}</nav>
      <div className="card">{sel === "site" ? <Field k="site" v={d.site} set={n => upd({ ...d, site: n })} /> : secIdx >= 0 && <><Field k="Section" v={{ nav: d.sections[secIdx].nav ?? "", ...d.sections[secIdx].data }} set={n => { const { nav, ...data } = n; upd({ ...d, sections: d.sections.map((x, i) => (i === secIdx ? { ...x, nav: nav || undefined, data } : x)) }); }} /></>}</div></div>}
    {tab === "sections" && <div className="max-w-2xl mx-auto p-4 space-y-2">{d.sections.map((x, i) => <div key={x.id} className="card !p-3 flex items-center gap-2"><b className="mr-auto">{x.id} <span className="text-xs text-ink/60">({x.type})</span></b><label className="text-sm"><input type="checkbox" checked={x.visible} onChange={e => upd({ ...d, sections: d.sections.map((y, j) => (j === i ? { ...y, visible: e.target.checked } : y)) })} /> Show</label><button aria-label="Move up" onClick={() => move(i, -1)}>↑</button><button aria-label="Move down" onClick={() => move(i, 1)}>↓</button><button className="text-burgundy text-sm" onClick={() => confirm(`Delete "${x.id}"?`) && upd({ ...d, sections: d.sections.filter((_, j) => j !== i) })}>Delete</button></div>)}
      <button className="btn bg-navy text-white" onClick={() => { const id = prompt("Name for the new section (letters, no spaces), e.g. dholera"); if (id) upd({ ...d, sections: [...d.sections.slice(0, -1), { id: id.replace(/\W/g, "-").toLowerCase(), type: "about", visible: true, nav: id, data: { heading: id, intro: ["[Write your text here]"], facts: [] } }, d.sections[d.sections.length - 1]] }); }}>+ Add new section</button></div>}
    {tab === "ai" && <div className="max-w-2xl mx-auto p-4 space-y-3"><h2 className="font-serif text-2xl text-navy">AI Website Editor</h2>{!info.ai && <p className="card text-burgundy">AI editing is not connected. Add ANTHROPIC_API_KEY on the server to enable it. Until then, use the Content and Sections tabs.</p>}
      <textarea className="inp" rows={6} value={instr} onChange={e => setInstr(e.target.value)} placeholder="e.g. Add a new section about Dholera Smart City / Update my WhatsApp number to … / Add a new consultancy service" /><button disabled={!info.ai || busy || !instr} className="btn bg-burgundy text-white disabled:opacity-40" onClick={ai}>{busy ? "Applying…" : "Apply Changes"}</button><p className="text-sm text-ink/70">Changes go to the draft and the preview. Nothing is public until you click Publish. Photos must be uploaded in the Content tab.</p></div>}
    {tab === "preview" && <div className="border-4 border-gold m-2"><Site content={d} preview /></div>}
  </div>;
}
