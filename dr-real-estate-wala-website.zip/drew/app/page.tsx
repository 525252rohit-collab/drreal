import Site from "@/components/Site";
import { load } from "@/lib/content";
export const dynamic = "force-dynamic";
export default async function Home() { return <Site content={(await load()).published} />; }
