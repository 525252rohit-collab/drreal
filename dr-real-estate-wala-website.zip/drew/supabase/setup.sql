create table if not exists site_content (id int primary key, data jsonb not null);
insert into storage.buckets (id, name, public) values ('site-media','site-media',true) on conflict do nothing;
alter table site_content enable row level security; -- only the server (service key) accesses it
