# Dr. Real Estate Wala website
Next.js 14 + TypeScript + Tailwind. Content, images and admin editing at `/admin`.

## Run locally
1. `npm install`  2. `cp .env.example .env.local` and set ADMIN_PASSWORD, SESSION_SECRET  3. `npm run dev`
Without Supabase keys the site runs in **demo mode** (saves to data/content.json; fine locally, NOT permanent on Vercel).

## Make edits permanent (Supabase)
1. supabase.com → New project. SQL editor → run `supabase/setup.sql`.
2. Project Settings → API: copy Project URL → SUPABASE_URL, service_role key → SUPABASE_SERVICE_KEY (keep secret, server-only).

## Deploy (Vercel) and connect domain
1. Push this folder to GitHub. vercel.com → Add New Project → import it.
2. Settings → Environment Variables: add everything from .env.example.
3. Deploy. Then Settings → Domains → add your domain and set the DNS records Vercel shows at your registrar (usually A 76.76.21.21 and CNAME www → cname.vercel-dns.com). SSL is automatic.

## Contact form delivery
Create a free Formspree form (or any webhook) and set FORM_WEBHOOK_URL. Until set, the form tells visitors to use WhatsApp.

## AI Website Editor
Set ANTHROPIC_API_KEY (server only). Without it the editor stays disabled; manual editing always works.

## Add your email
Admin → Content → "Site, contact & images" → email.
