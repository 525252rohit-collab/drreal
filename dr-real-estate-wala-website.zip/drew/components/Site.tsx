"use client";
import { useState } from "react";
import type { Content, Section } from "@/lib/content";
const Img = ({ src, alt, className }: { src: string; alt: string; className?: string }) => /* eslint-disable-next-line @next/next/no-img-element */ <img src={src} alt={alt} loading="lazy" className={className} />;
const H = ({ children }: { children: React.ReactNode }) => <h2 className="font-serif text-3xl md:text-4xl text-navy max-w-3xl mb-10">{children}</h2>;
const yt = (u: string) => { const m = u.match(/(?:v=|youtu\.be\/|embed\/)([\w-]{11})/); return m ? `https://www.youtube.com/embed/${m[1]}` : ""; };

export default function Site({ content, preview }: { content: Content; preview?: boolean }) {
  const s = content.site; const wa = `https://wa.me/${s.whatsapp}?text=${encodeURIComponent(s.waMessage)}`;
  const link = (l: string) => (l === "wa" ? wa : l);
  const secs = content.sections.filter(x => x.visible);
  const [menu, setMenu] = useState(false);
  const nav = secs.filter(x => x.nav);
  const render = (x: Section, i: number) => {
    const d = x.data; const bg = i % 2 ? "bg-ghost" : "";
    const wrap = (c: React.ReactNode) => <section id={x.id} key={x.id} className={`${bg} px-5 py-16 md:py-24 scroll-mt-16`}><div className="max-w-6xl mx-auto">{c}</div></section>;
    switch (x.type) {
      case "hero": return <section id={x.id} key={x.id} className="relative overflow-hidden bg-gradient-to-br from-paper via-paper to-ghost px-5 pt-28 pb-16 md:pt-32">
        <div aria-hidden className="absolute -right-24 -top-24 w-[32rem] h-[32rem] rounded-full bg-burgundy/10 float" /><div aria-hidden className="absolute -left-20 bottom-0 w-72 h-72 rounded-full bg-gold/15 float" />
        <div className="relative max-w-6xl mx-auto grid md:grid-cols-2 gap-10 items-center">
          <div><Img src={s.logo} alt={`${s.brand} logo`} className="h-28 md:h-36 w-auto mb-4 -ml-2" />
            <h1 className="font-serif text-4xl md:text-5xl text-navy leading-tight">{d.headline}</h1>
            <p className="mt-4 font-serif text-2xl text-burgundy">{s.brand}</p><p className="font-semibold text-navy">{s.name}</p>
            <p className="mt-1 text-sm text-ink/80">{d.role}</p>
            <p className="mt-3 text-lg text-gold font-medium">{s.tagline}</p>
            <p className="mt-4 text-ink/80 max-w-xl">{d.text}</p>
            <div className="mt-7 flex flex-wrap gap-3"><a className="btn bg-burgundy text-white" href={link(d.cta1Link)}>{d.cta1}</a><a className="btn border border-navy text-navy" href={link(d.cta2Link)}>{d.cta2}</a><a className="btn bg-navy text-white" href={link(d.cta3Link)}>{d.cta3}</a></div></div>
          <div className="relative mx-auto w-full max-w-sm"><div aria-hidden className="absolute inset-4 translate-x-4 translate-y-4 rounded-[2rem] bg-gradient-to-br from-gold to-burgundy opacity-80" />
            <Img src={s.portrait} alt={s.name} className="relative rounded-[2rem] shadow-2xl border-4 border-white object-cover aspect-[3/4] w-full" /></div></div></section>;
      case "about": return wrap(<div className="grid md:grid-cols-5 gap-10 items-start"><Img src={s.portrait} alt={s.name} className="md:col-span-2 rounded-2xl shadow-xl aspect-[4/5] object-cover object-top w-full" />
        <div className="md:col-span-3"><H>{d.heading}</H><div className="space-y-4 text-lg leading-relaxed max-w-prose">{d.intro.map((p: string, k: number) => <p key={k}>{p}</p>)}</div>
          <dl className="mt-8 grid sm:grid-cols-3 gap-4">{d.facts.map((f: any, k: number) => <div key={k} className="card"><dt className="font-semibold text-burgundy">{f.label}</dt><dd className="mt-1 text-sm">{f.value}</dd></div>)}</dl></div></div>);
      case "timeline": return wrap(<><H>{d.heading}</H><ol className="relative border-l-2 border-gold/60 ml-3 space-y-8">{d.items.map((m: any, k: number) => <li key={k} className="pl-8 relative"><span aria-hidden className="absolute -left-[9px] top-2 w-4 h-4 rounded-full bg-burgundy ring-4 ring-paper" />
        <div className="card grid sm:grid-cols-[1fr_auto] gap-4"><div><p className="text-sm text-gold font-semibold">{m.date}</p><h3 className="font-serif text-xl text-navy">{m.title}</h3><p className="mt-1">{m.text}</p></div>{m.image && <Img src={m.image} alt={m.title} className="w-full sm:w-40 h-28 object-cover rounded-lg" />}</div></li>)}</ol></>);
      case "drew": return wrap(<div className="grid md:grid-cols-3 gap-10"><div className="md:col-span-1 text-center"><div className="card"><Img src={s.logo} alt="DREW Network logo" className="w-full max-w-xs mx-auto" /></div>{d.images?.map((im: string, k: number) => im && <Img key={k} src={im} alt="DREW Network" className="mt-4 rounded-xl" />)}</div>
        <div className="md:col-span-2"><H>{d.heading}</H><p className="-mt-6 mb-8 text-burgundy font-semibold">{d.sub}</p><div className="grid sm:grid-cols-2 gap-4">{d.points.map((p: any, k: number) => <div key={k} className="card"><h3 className="font-serif text-lg text-navy">{p.title}</h3><p className="text-sm mt-1">{p.text}</p></div>)}</div>
          <a href={link(d.ctaLink)} className="btn bg-burgundy text-white mt-8">{d.cta}</a></div></div>);
      case "cards": return wrap(<><H>{d.heading}</H><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">{d.items.map((c: any, k: number) => <div key={k} className="card flex flex-col"><div className="text-3xl" aria-hidden>{c.icon}</div><h3 className="font-serif text-xl text-navy mt-3">{c.title}</h3>{c.text && <p className="text-sm mt-2 flex-1">{c.text}</p>}{d.button && <a href="#contact" className="btn mt-4 border border-burgundy text-burgundy text-center">{d.button}</a>}</div>)}</div></>);
      case "mission": return wrap(<><H>{d.heading}</H><div className="grid md:grid-cols-2 gap-5"><div className="card"><h3 className="font-serif text-xl text-burgundy">Vision</h3><p className="mt-2">{d.vision}</p></div><div className="card"><h3 className="font-serif text-xl text-burgundy">Mission</h3><p className="mt-2">{d.mission}</p></div></div>
        <div className="mt-8 rounded-2xl bg-navy text-white text-center py-10 px-6"><p className="font-serif text-2xl md:text-3xl text-gold">{d.banner}</p></div></>);
      case "testimonials": return wrap(<Testi d={d} />);
      case "gallery": return wrap(<><H>{d.heading}</H>{!d.items.length && !d.videos.length && <p className="text-ink/60">Photos and videos will appear here once added from the admin dashboard.</p>}<div className="grid grid-cols-2 md:grid-cols-3 gap-4">{d.items.map((g: any, k: number) => <figure key={k}><Img src={g.image} alt={g.caption || "Gallery"} className="rounded-xl aspect-[4/3] object-cover w-full" />{g.caption && <figcaption className="text-sm mt-1">{g.caption}{g.category && <span className="text-gold"> · {g.category}</span>}</figcaption>}</figure>)}
        {d.videos.map((v: any, k: number) => yt(v.url) && <div key={k}><iframe title={v.caption || "Video"} src={yt(v.url)} className="rounded-xl aspect-video w-full" allowFullScreen loading="lazy" />{v.caption && <p className="text-sm mt-1">{v.caption}</p>}</div>)}</div></>);
      case "contact": return wrap(<div className="grid md:grid-cols-2 gap-10"><div><H>{d.heading}</H><ul className="space-y-2 mb-6"><li><b>{s.name}</b> · {s.brand}</li><li>Mobile: <a className="underline" href={`tel:+91${s.phone}`}>{s.phone}</a></li>{s.email && <li>Email: <a className="underline" href={`mailto:${s.email}`}>{s.email}</a></li>}<li>{s.location}</li></ul>
        <div className="flex flex-wrap gap-3"><a className="btn bg-[#1d9e55] text-white" href={wa}>WhatsApp</a><a className="btn bg-navy text-white" href={`tel:+91${s.phone}`}>Call Now</a>{s.email && <a className="btn border border-navy text-navy" href={`mailto:${s.email}`}>Email</a>}</div>
        {s.mapEmbed && <iframe title="Location map" src={s.mapEmbed} className="mt-6 w-full h-56 rounded-xl border-0" loading="lazy" />}</div><Form d={d} /></div>);
      default: return null;
    }
  };
  return <div className={preview ? "" : ""}>
    <header className="fixed top-0 inset-x-0 z-40 bg-paper/80 backdrop-blur border-b border-gold/30"><div className="max-w-6xl mx-auto flex items-center justify-between px-5 h-16">
      <a href="#home" className="flex items-center gap-2"><Img src={s.logo} alt={s.brand} className="h-11 w-11 object-contain" /><span className="font-serif text-navy hidden sm:block">{s.brand}</span></a>
      <nav aria-label="Main" className="hidden lg:flex gap-6 text-sm font-semibold text-navy">{nav.map(n => <a key={n.id} href={`#${n.id}`} className="hover:text-burgundy">{n.nav!.toUpperCase()}</a>)}</nav>
      <div className="flex items-center gap-2"><a href="#contact" className="btn bg-burgundy text-white !py-2 text-sm">Book Consultation</a><button className="lg:hidden p-2 text-navy" aria-label="Menu" aria-expanded={menu} onClick={() => setMenu(!menu)}>☰</button></div></div>
      {menu && <nav className="lg:hidden bg-paper px-5 pb-4 grid gap-3 font-semibold text-navy">{nav.map(n => <a key={n.id} href={`#${n.id}`} onClick={() => setMenu(false)}>{n.nav}</a>)}</nav>}</header>
    <main>{secs.map(render)}</main>
    <footer className="bg-navy text-white px-5 py-12"><div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
      <div><Img src={s.logo} alt="" className="h-20 bg-white rounded-xl p-1" /><p className="font-serif text-xl mt-3">{s.brand}</p><p className="text-gold text-sm mt-1">{s.tagline}</p></div>
      <div><p className="font-semibold mb-2">Quick links</p><ul className="space-y-1 text-sm">{nav.map(n => <li key={n.id}><a href={`#${n.id}`}>{n.nav}</a></li>)}</ul></div>
      <div><p className="font-semibold mb-2">Connect</p><p className="text-sm">{s.phone} · {s.location}</p><div className="flex gap-4 mt-2 text-sm underline">{[["Instagram", s.instagram], ["YouTube", s.youtube], ["Facebook", s.facebook]].map(([n, u]) => u && <a key={n} href={u} target="_blank" rel="noreferrer">{n}</a>)}</div></div></div>
      <div className="max-w-6xl mx-auto mt-8 pt-6 border-t border-white/20 text-xs text-white/80 space-y-2"><p><b>Disclaimer:</b> {s.disclaimer}</p><p>© {new Date().getFullYear()} {s.brand}. All rights reserved. Privacy: details you submit are used only to respond to your enquiry.</p></div></footer>
    <a href={wa} target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp" className="fixed bottom-5 right-5 z-50 w-14 h-14 rounded-full bg-[#25D366] text-white grid place-items-center shadow-xl text-2xl hover:scale-110 transition">💬</a>
  </div>;
}
function Testi({ d }: { d: any }) {
  const [i, setI] = useState(0); const t = d.items[i];
  return <><H>{d.heading}</H>{t && <div className="card max-w-2xl"><p className="text-lg">“{t.text}”</p><div className="flex items-center gap-3 mt-4">{t.photo && <Img src={t.photo} alt={t.name} className="w-12 h-12 rounded-full object-cover" />}<b>{t.name}</b></div>{yt(t.video || "") && <iframe title="Video testimonial" src={yt(t.video)} className="mt-4 w-full aspect-video rounded-lg" allowFullScreen loading="lazy" />}
    {d.items.length > 1 && <div className="mt-4 flex gap-2"><button className="btn border" onClick={() => setI((i + d.items.length - 1) % d.items.length)}>Previous</button><button className="btn border" onClick={() => setI((i + 1) % d.items.length)}>Next</button></div>}</div>}</>;
}
function Form({ d }: { d: any }) {
  const [st, setSt] = useState<{ ok?: boolean; msg?: string }>({}); const [busy, setBusy] = useState(false);
  async function go(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); const b = Object.fromEntries(new FormData(e.currentTarget));
    const r = await fetch("/api/contact", { method: "POST", body: JSON.stringify(b) }); const j = await r.json(); setBusy(false);
    setSt(r.ok ? { ok: true, msg: "Thank you! Dr. Rajann will contact you soon." } : { msg: j.error });
  }
  return <form onSubmit={go} className="card space-y-3" noValidate={false}>
    <label className="block">Full name<input name="name" required className="inp" autoComplete="name" /></label>
    <label className="block">Mobile number<input name="mobile" required pattern="[+\d\s\-]{10,15}" inputMode="tel" className="inp" autoComplete="tel" /></label>
    <label className="block">Email address<input name="email" type="email" className="inp" autoComplete="email" /></label>
    <label className="block">Interested in<select name="interest" className="inp">{d.interests.map((o: string) => <option key={o}>{o}</option>)}</select></label>
    <label className="block">Investment budget<select name="budget" className="inp">{d.budgets.map((o: string) => <option key={o}>{o}</option>)}</select></label>
    <label className="block">Message<textarea name="message" rows={3} className="inp" /></label>
    <button disabled={busy} className="btn bg-burgundy text-white w-full">{busy ? "Sending…" : "Send Enquiry"}</button>
    {st.msg && <p role="status" className={st.ok ? "text-green-700" : "text-burgundy"}>{st.msg}</p>}</form>;
}
