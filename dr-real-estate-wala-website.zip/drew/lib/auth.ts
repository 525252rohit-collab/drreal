import { createHmac } from "crypto";
import { cookies } from "next/headers";
export const makeToken = () => createHmac("sha256", process.env.SESSION_SECRET || "dev-secret").update(process.env.ADMIN_PASSWORD || "").digest("hex");
export function isAdmin() { return !!process.env.ADMIN_PASSWORD && cookies().get("drew_admin")?.value === makeToken(); }
