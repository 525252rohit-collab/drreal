import fs from "fs/promises";
import path from "path";
export type Section = { id: string; type: string; visible: boolean; nav?: string; data: any };
export type Content = { site: any; sections: Section[] };
export type Store = { draft: Content; published: Content; previous?: Content };
const mk = (names: string[][], text = "[Add a short description]") => names.map(([title, icon]) => ({ icon, title, text }));
export const DEFAULT: Content = {
  site: { title: "Dr. Real Estate Wala – Dr. Rajann Aadarsh", description: "Real estate education, investment guidance and consultation in Delhi NCR.", name: "Dr. Rajann Aadarsh", brand: "DR. REAL ESTATE WALA", phone: "9355151787", whatsapp: "919355151787", email: "", location: "Delhi NCR, India", instagram: "https://www.instagram.com/dr.realestatewalaofficial", youtube: "https://youtube.com/@drrealestatewala", facebook: "https://www.facebook.com/share/1CedpsViJV/", portrait: "/portrait.jpeg", logo: "/logo.png", mapEmbed: "", waMessage: "Hello Dr. Real Estate Wala, I want to know more about your real estate consultation services.", tagline: "प्रॉपर्टी का सही डायग्नोसिस, वेल्थ एजुकेशन की पक्की डोज़!", disclaimer: "All property investments involve risks. Information provided on this website is for educational and informational purposes and does not guarantee returns or profits. Please conduct independent due diligence before making any investment decision." },
  sections: [
    { id: "home", type: "hero", visible: true, nav: "Home", data: { headline: "Welcome to the World of Smart Real Estate Investment", role: "Real Estate Doctor | Property Investment Consultant | Certified RPM Master Trainer", text: "Helping people understand real estate opportunities, make informed property decisions and build long-term wealth through the right knowledge, guidance and network.", cta1: "Book Free Consultation", cta1Link: "#contact", cta2: "Explore My Journey", cta2Link: "#journey", cta3: "Connect on WhatsApp", cta3Link: "wa" } },
    { id: "about", type: "about", visible: true, nav: "About Me", data: { heading: "Meet Your Real Estate Doctor", intro: ["Namaste! I am Dr. Rajann Aadarsh, popularly known as Dr. Real Estate Wala.", "My vision is to make real estate investment easier to understand through proper education, market awareness, expert guidance and a strong professional network.", "I believe that property investment should not be based on guesswork. It should be based on knowledge, research, the right strategy and informed decisions.", "Through my journey, I aim to help individuals understand property opportunities, develop an investment mindset and move towards financial growth."], facts: [{ label: "Achievements", value: "[Add your achievements]" }, { label: "Qualifications", value: "[Add your qualifications]" }, { label: "Experience", value: "[Add your experience]" }] } },
    { id: "journey", type: "timeline", visible: true, nav: "My Journey", data: { heading: "My Journey – From Vision to Real Estate Wealth Creation", items: ["My Beginning", "My Entry into Real Estate", "Learning & Market Understanding", "Building Professional Connections", "Joining & Growing with DREW Network", "Becoming a Real Estate Educator", "My Vision for the Future"].map(t => ({ date: "[Add date]", title: t, text: "[Add your story in the admin dashboard]", image: "" })) } },
    { id: "drew", type: "drew", visible: true, nav: "DREW Network", data: { heading: "Grow Together with DREW Network", sub: "Knowledge | Network | Deals | Returns | Education | Wealth", cta: "Discover the Power of DREW Network", ctaLink: "#contact", points: [["Real Estate Education", "Learn how property markets work before you invest."], ["Professional Networking", "Connect with people who share an informed investing mindset."], ["Investment Opportunities", "Understand opportunities with the right questions in hand."], ["Property Deal Understanding", "Learn to read deals, documents and risks."], ["Wealth Creation Mindset", "Think long term, with strategy rather than guesswork."], ["Community & Collaboration", "Grow together through shared knowledge."]].map(([title, text]) => ({ title, text })), images: [] } },
    { id: "services", type: "cards", visible: true, nav: "Services", data: { heading: "How Can I Help You?", button: "Contact Now", items: mk([["Real Estate Investment Guidance", "🧭"], ["Property Buying Consultation", "🏠"], ["Land & Plot Investment Education", "🗺️"], ["Real Estate Market Understanding", "📊"], ["Investment Strategy & Planning", "🎯"], ["Real Estate Business Mentorship", "🤝"]]) } },
    { id: "why", type: "cards", visible: true, data: { heading: "Why Choose Dr. Real Estate Wala?", items: mk([["Knowledge-Driven Guidance", "💡"], ["Transparent Communication", "🔍"], ["Investment Education", "🎓"], ["Professional Network", "🌐"], ["Growth-Oriented Mindset", "📈"], ["Personal Consultation", "👤"]], "") } },
    { id: "mission", type: "mission", visible: true, data: { heading: "My Mission – Empowering People Through Real Estate Education", vision: "To create an informed community of real estate investors and help people understand the power of knowledge, networking and smart property decisions.", mission: "To simplify real estate education and make professional guidance accessible to aspiring investors.", banner: "Learn to Invest and Invest to Grow" } },
    { id: "testimonials", type: "testimonials", visible: false, data: { heading: "Testimonials & Success Stories", items: [{ name: "[SAMPLE – replace with a real client]", photo: "", text: "[SAMPLE placeholder. Add a genuine testimonial with the client's permission.]", video: "" }] } },
    { id: "gallery", type: "gallery", visible: true, nav: "Gallery", data: { heading: "Gallery", items: [], videos: [] } },
    { id: "contact", type: "contact", visible: true, nav: "Contact", data: { heading: "Let's Discuss Your Real Estate Goals!", interests: ["Investment guidance", "Buying a property", "Land & plots", "Business mentorship", "Other"], budgets: ["Under ₹25 lakh", "₹25–50 lakh", "₹50 lakh–1 crore", "Above ₹1 crore", "Not sure yet"] } },
  ],
};
const FILE = path.join(process.cwd(), "data", "content.json");
const sb = () => process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_KEY ? { u: process.env.SUPABASE_URL, k: process.env.SUPABASE_SERVICE_KEY } : null;
export const mode = () => (sb() ? "supabase" : "demo");
export async function load(): Promise<Store> {
  try {
    const c = sb(); let d: any;
    if (c) { const r = await fetch(`${c.u}/rest/v1/site_content?id=eq.1&select=data`, { headers: { apikey: c.k, Authorization: `Bearer ${c.k}` }, cache: "no-store" }); d = (await r.json())[0]?.data; }
    else d = JSON.parse(await fs.readFile(FILE, "utf8"));
    if (d?.published) return d;
  } catch {}
  return { draft: DEFAULT, published: DEFAULT };
}
export async function save(s: Store) {
  const c = sb();
  if (c) { const r = await fetch(`${c.u}/rest/v1/site_content`, { method: "POST", headers: { apikey: c.k, Authorization: `Bearer ${c.k}`, "Content-Type": "application/json", Prefer: "resolution=merge-duplicates" }, body: JSON.stringify({ id: 1, data: s }) }); if (!r.ok) throw new Error(await r.text()); }
  else await fs.writeFile(FILE, JSON.stringify(s));
}
export async function upload(name: string, buf: Buffer, type: string): Promise<string> {
  const c = sb(); const safe = Date.now() + "-" + name.replace(/[^\w.-]/g, "_");
  if (c) { const r = await fetch(`${c.u}/storage/v1/object/site-media/${safe}`, { method: "POST", headers: { apikey: c.k, Authorization: `Bearer ${c.k}`, "Content-Type": type }, body: buf }); if (!r.ok) throw new Error(await r.text()); return `${c.u}/storage/v1/object/public/site-media/${safe}`; }
  await fs.writeFile(path.join(process.cwd(), "public", "uploads", safe), buf); return "/uploads/" + safe;
}
