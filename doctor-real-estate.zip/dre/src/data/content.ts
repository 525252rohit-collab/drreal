// ─────────────────────────────────────────────────────────────
// EDIT EVERYTHING HERE. Components read only from this file.
// ─────────────────────────────────────────────────────────────
export const site = {
  name: "Doctor Real Estate",
  tagline: "Real Estate · Strategy · Networking · Growth",
  positioning: "Real Estate Strategist · Entrepreneur · Network Builder",
  headline: "I build properties, partnerships & possibilities.",
  supporting: "Real Estate · Business Growth · Strategic Networking",
  phone: "+91 00000 00000",
  whatsapp: "https://wa.me/910000000000", // replace with your number
  email: "hello@example.com",
  social: {
    Instagram: "https://instagram.com/",
    LinkedIn: "https://linkedin.com/",
    Facebook: "https://facebook.com/",
  },
  // Photo & logo files live in /public/images
  photo: { src: "/images/photo-1000.webp", small: "/images/photo-600.webp", alt: "Portrait of Doctor Real Estate" },
  logo: { src: "/images/logo.webp", small: "/images/logo-small.webp", alt: "Drivnetwork logo" },
};

export const nav = [
  { n: "01", label: "Home", id: "home" },
  { n: "02", label: "About", id: "about" },
  { n: "03", label: "Services", id: "services" },
  { n: "04", label: "Network", id: "network" },
  { n: "05", label: "Contact", id: "contact" },
];

export const about = {
  headline: "Building relationships that create real opportunities.",
  body: [
    "Doctor Real Estate connects people, properties and opportunities through relationships built on trust. The focus is not simply on transactions, but on meaningful connections that lead to sustainable growth.",
    "From investors and developers to entrepreneurs and first-time buyers, every conversation starts with listening, then maps to the opportunity that genuinely fits. Partnerships last when both sides win.",
  ],
};

// value: number, suffix: shown after the number
export const stats = [
  { value: 10, suffix: "+", label: "Years of experience" },
  { value: 100, suffix: "+", label: "Connections" },
  { value: 50, suffix: "+", label: "Opportunities" },
  { value: 1, suffix: "", label: "Growing network" },
];

export const services = [
  { n: "01", title: "Real Estate Advisory", text: "Strategic guidance for property buyers, investors, developers and business owners." },
  { n: "02", title: "Property Opportunities", text: "Helping clients discover relevant property and investment opportunities." },
  { n: "03", title: "Business & Network Growth", text: "Connecting entrepreneurs, professionals, developers and partners through meaningful relationships." },
  { n: "04", title: "Strategic Partnerships", text: "Building collaborations between the right people, businesses and opportunities." },
];

export const pillars = [
  { n: "01", title: "Trust", text: "Every meaningful transaction begins with trust." },
  { n: "02", title: "Opportunity", text: "Find the right opportunity at the right time." },
  { n: "03", title: "Relationships", text: "Build relationships that create long-term value." },
  { n: "04", title: "Growth", text: "Create sustainable growth for everyone involved." },
];

export const network = {
  center: "Doctor Real Estate",
  nodes: ["Property Developers", "Investors", "Channel Partners", "Brokers", "Entrepreneurs", "Business Owners", "Corporate Professionals", "Buyers", "Sellers"],
};

// Add more images: drop files in /public/images and push an entry here.
// `pos` and `zoom` crop the same photo differently until you add more.
export const gallery = [
  { src: "/images/photo-1000.webp", alt: "Portrait", category: "Real Estate", pos: "50% 20%", zoom: 1 },
  { src: "/images/photo-1000.webp", alt: "Portrait, close crop", category: "Networking", pos: "50% 22%", zoom: 1.7 },
  { src: "/images/photo-1000.webp", alt: "Portrait, detail", category: "Business", pos: "45% 60%", zoom: 1.8 },
  { src: "/images/photo-1000.webp", alt: "Portrait, wide", category: "Events", pos: "50% 50%", zoom: 1.15 },
];

export const testimonials = [
  { quote: "Replace with a real client testimonial about working with Doctor Real Estate.", name: "Client Name", role: "Investor" },
  { quote: "Replace with a real partner testimonial describing the outcome and the experience.", name: "Client Name", role: "Business Owner" },
  { quote: "Replace with a real developer or channel partner testimonial.", name: "Client Name", role: "Developer" },
];

export const drivnetwork = {
  headline: "Where relationships create possibilities.",
  body: [
    "Drivnetwork is the ecosystem behind the work: a growing circle of developers, investors, entrepreneurs and professionals who believe good deals come from good relationships.",
    "Doctor Real Estate is its property-focused voice, bringing the right people to the right opportunities and keeping every introduction honest, useful and long-term.",
  ],
  cta: { label: "Join the Network", href: "#contact" },
};

export const cta = {
  headline: "Let’s build something meaningful.",
  body: "Looking for the right property, investment opportunity, business connection or strategic partnership? Start with a conversation.",
};
