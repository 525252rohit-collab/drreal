import { pillars } from "../data/content";
import Reveal, { SectionLabel } from "./Reveal";

export default function Philosophy() {
  return (
    <section id="philosophy" className="section bg-ink text-white">
      <div className="wrap">
        <SectionLabel n="03" text="PHILOSOPHY" light />
        <Reveal><h2 className="h-display text-[clamp(2.4rem,5.5vw,5rem)]">Four pillars. One vision.</h2></Reveal>
        <div className="mt-16 divide-y divide-white/15 border-y border-white/15">
          {pillars.map((p, i) => (
            <Reveal key={p.n} delay={i * 60}>
              <div className="grid items-baseline gap-4 py-10 md:grid-cols-12 md:py-14">
                <span className="text-sm text-goldsoft md:col-span-1">{p.n}</span>
                <h3 className="font-display text-[clamp(3rem,8vw,7rem)] font-light leading-none md:col-span-7">{p.title}</h3>
                <p className="max-w-xs text-lg text-white/65 md:col-span-4">{p.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
