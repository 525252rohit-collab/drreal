import { stats } from "../data/content";
import { useCountUp, useInView } from "../hooks/hooks";

function Stat({ value, suffix, label, run }: { value: number; suffix: string; label: string; run: boolean }) {
  const v = useCountUp(value, run);
  return (
    <div className="border-t border-ink/20 pt-5">
      <p className="font-display text-6xl font-light tabular-nums md:text-7xl">{v}{suffix}</p>
      <p className="mt-2 text-sm text-mute">{label}</p>
    </div>
  );
}

export default function Stats() {
  const [ref, seen] = useInView<HTMLDivElement>(0.4);
  return (
    <div ref={ref} className="mt-24 grid grid-cols-2 gap-x-6 gap-y-10 md:mt-32 md:grid-cols-4" aria-label="Key figures">
      {stats.map((s) => <Stat key={s.label} {...s} run={seen} />)}
    </div>
  );
}
