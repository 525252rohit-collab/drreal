import { ReactNode } from "react";
import { useInView } from "../hooks/hooks";

export default function Reveal({ children, delay = 0, className = "" }: { children: ReactNode; delay?: number; className?: string }) {
  const [ref, seen] = useInView<HTMLDivElement>(0.15);
  return (
    <div ref={ref} style={{ ["--d" as string]: `${delay}ms` }} className={`reveal ${seen ? "in" : ""} ${className}`}>
      {children}
    </div>
  );
}

export function SectionLabel({ n, text, light = false }: { n: string; text: string; light?: boolean }) {
  return <p className={`label mb-6 ${light ? "!text-goldsoft" : ""}`}>({n}) — {text}</p>;
}
