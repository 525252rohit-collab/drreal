import { site } from "../data/content";
import { useScrollY } from "../hooks/hooks";

export default function Hero() {
  const y = Math.min(useScrollY(), 900);
  return (
    <section id="home" className="relative min-h-[100svh] overflow-hidden bg-ink text-white">
      <div className="absolute inset-0 bg-[radial-gradient(60%_60%_at_75%_40%,#10275C_0%,transparent_70%)]" aria-hidden />
      <div className="wrap relative grid min-h-[100svh] items-end gap-0 pb-10 pt-24 lg:grid-cols-12 lg:items-center lg:pb-0">
        <div className="relative z-10 order-2 pb-6 lg:order-1 lg:col-span-7 lg:pb-0">
          <p className="mb-6 max-w-md text-[11px] font-semibold uppercase leading-relaxed tracking-[0.2em] text-goldsoft">{site.positioning}</p>
          <h1 className="h-display text-[clamp(3.4rem,10.5vw,10rem)] lg:-mr-48">Doctor<br />Real Estate</h1>
          <p className="mt-8 max-w-xl font-display text-2xl font-light italic text-white/85 md:text-3xl">{site.headline}</p>
          <div className="mt-10 flex flex-col gap-3 sm:flex-row">
            <a href="#contact" className="btn btn-gold">Let’s Connect <span className="arrow">→</span></a>
            <a href="#services" className="btn btn-line">What I Do</a>
          </div>
          <p className="mt-10 text-sm text-white/55">{site.supporting}</p>
        </div>
        <figure className="relative order-1 mx-auto mb-8 w-[68%] max-w-[300px] lg:order-2 lg:col-span-5 lg:mb-0 lg:w-full lg:max-w-[460px] lg:justify-self-end">
          <div className="overflow-hidden border border-white/15" style={{ aspectRatio: "2 / 3" }}>
            <img src={site.photo.src} srcSet={`${site.photo.small} 600w, ${site.photo.src} 1000w`} sizes="(min-width:1024px) 460px, 70vw"
                 alt={site.photo.alt} fetchPriority="high" width={1000} height={1503}
                 className="h-full w-full object-cover" style={{ transform: `translateY(${y * 0.06}px) scale(1.08)` }} />
          </div>
          <span className="absolute -bottom-3 -left-3 hidden h-24 w-24 border-b border-l border-gold lg:block" aria-hidden />
        </figure>
      </div>
      <a href="#about" className="absolute bottom-6 right-5 hidden text-[11px] font-semibold tracking-[0.2em] text-white/60 hover:text-white sm:block lg:right-12">SCROLL ↓</a>
    </section>
  );
}
