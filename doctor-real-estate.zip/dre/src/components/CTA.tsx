import { cta, site } from "../data/content";
import Reveal from "./Reveal";

export default function CTA() {
  return (
    <section id="contact" className="section relative overflow-hidden bg-navy text-white">
      <div className="wrap relative">
        <Reveal><h2 className="h-display text-[clamp(3rem,9vw,8.5rem)]">{cta.headline}</h2></Reveal>
        <Reveal delay={80}><p className="mt-10 max-w-xl text-lg leading-relaxed text-white/75">{cta.body}</p></Reveal>
        <Reveal delay={140}>
          <div className="mt-10 flex flex-col gap-3 sm:flex-row">
            <a href={`mailto:${site.email}?subject=Enquiry%20for%20Doctor%20Real%20Estate`} className="btn btn-gold">Enquire Now <span className="arrow">→</span></a>
            <a href={site.whatsapp} target="_blank" rel="noopener noreferrer" className="btn btn-line">WhatsApp</a>
          </div>
          <p className="mt-8 flex items-center gap-3 text-sm text-goldsoft"><span className="h-2 w-2 rounded-full bg-goldsoft" aria-hidden />Open to partnerships &amp; opportunities</p>
        </Reveal>
      </div>
    </section>
  );
}
