import { useEffect, useState } from "react";
import { nav, site } from "../data/content";
import { useActiveSection, useScrollY } from "../hooks/hooks";

const ids = nav.map((n) => n.id);

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const y = useScrollY();
  const active = useActiveSection(ids);
  const solid = y > 40 || open;
  useEffect(() => { document.body.style.overflow = open ? "hidden" : ""; }, [open]);

  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${solid ? "bg-ink/90 backdrop-blur-md" : "bg-transparent"} text-white`}>
      <div className="wrap flex h-16 items-center justify-between">
        <a href="#home" className="text-[13px] font-bold tracking-[0.22em]" onClick={() => setOpen(false)}>DOCTOR REAL ESTATE</a>
        <nav aria-label="Primary" className="hidden lg:block">
          <ul className="flex gap-9">
            {nav.map((l) => (
              <li key={l.id}>
                <a href={`#${l.id}`} aria-current={active === l.id ? "true" : undefined}
                   className={`flex items-baseline gap-2 text-sm transition-colors ${active === l.id ? "text-goldsoft" : "text-white/70 hover:text-white"}`}>
                  <span className="text-[10px] tabular-nums">{l.n}</span>{l.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <a href="#contact" className="hidden border border-white/40 px-5 py-2 text-sm font-semibold transition hover:border-gold hover:bg-gold hover:text-ink lg:inline-block">Let’s Connect</a>
        <button className="flex h-10 w-10 flex-col items-center justify-center gap-[6px] lg:hidden" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen(!open)}>
          <span className={`h-px w-6 bg-white transition ${open ? "translate-y-[7px] rotate-45" : ""}`} />
          <span className={`h-px w-6 bg-white transition ${open ? "opacity-0" : ""}`} />
          <span className={`h-px w-6 bg-white transition ${open ? "-translate-y-[7px] -rotate-45" : ""}`} />
        </button>
      </div>
      <div id="mobile-menu" hidden={!open} className="fixed inset-x-0 top-16 h-[calc(100dvh-4rem)] overflow-y-auto bg-ink px-5 pb-10 pt-8 lg:hidden">
        <ul>
          {nav.map((l) => (
            <li key={l.id} className="border-b border-white/10">
              <a href={`#${l.id}`} onClick={() => setOpen(false)} className="flex items-baseline gap-4 py-5 font-display text-4xl font-light">
                <span className="font-sans text-xs text-goldsoft">{l.n}</span>{l.label}
              </a>
            </li>
          ))}
        </ul>
        <a href="#contact" onClick={() => setOpen(false)} className="btn btn-gold mt-8">Let’s Connect <span className="arrow">→</span></a>
        <a href={site.whatsapp} className="mt-4 block text-center text-sm text-white/60">{site.phone}</a>
      </div>
    </header>
  );
}
