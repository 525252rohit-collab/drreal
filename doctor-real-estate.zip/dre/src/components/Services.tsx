import { services } from "../data/content";
import Reveal, { SectionLabel } from "./Reveal";

export default function Services() {
  return (
    <section id="services" className="section bg-white">
      <div className="wrap">
        <SectionLabel n="02" text="WHAT I DO" />
        <Reveal><h2 className="h-display max-w-3xl text-[clamp(2.4rem,5.5vw,5rem)]">Four ways to create real estate growth.</h2></Reveal>
        <ul className="mt-16 grid gap-px bg-stone sm:grid-cols-2">
          {services.map((s, i) => (
            <li key={s.n} className="bg-white">
              <Reveal delay={i * 70}>
                <a href="#contact" className="group relative flex min-h-[300px] flex-col justify-between overflow-hidden p-8 transition-colors duration-500 hover:bg-navy hover:text-white md:p-10">
                  <span className="text-sm text-gold">{s.n}</span>
                  <div>
                    <h3 className="font-display text-3xl font-light md:text-4xl">{s.title}</h3>
                    <p className="mt-4 max-w-sm text-base leading-relaxed text-mute transition-colors group-hover:text-white/70">{s.text}</p>
                  </div>
                  <span className="absolute right-8 top-7 text-2xl transition-transform duration-500 group-hover:-translate-y-1 group-hover:translate-x-1 md:right-10" aria-hidden>↗</span>
                  <span className="sr-only">Enquire about {s.title}</span>
                </a>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
