import { network } from "../data/content";
import Reveal, { SectionLabel } from "./Reveal";

export default function Network() {
  const n = network.nodes.length;
  const pts = network.nodes.map((label, i) => {
    const a = (i / n) * Math.PI * 2 - Math.PI / 2;
    return { label, x: 50 + 38 * Math.cos(a), y: 50 + 38 * Math.sin(a) };
  });
  return (
    <section id="network" className="section overflow-hidden">
      <div className="wrap">
        <SectionLabel n="04" text="THE NETWORK" />
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <Reveal><h2 className="h-display text-[clamp(2.4rem,5.5vw,5rem)]">An ecosystem built on trust.</h2></Reveal>
            <Reveal delay={80}><p className="mt-8 max-w-md text-lg leading-relaxed text-ink/75">
              Doctor Real Estate works with, and connects, everyone a property decision touches: from the people who build and fund to the people who buy, sell and advise.
            </p></Reveal>
          </div>
          <Reveal className="lg:col-span-7">
            <div className="relative mx-auto aspect-square w-full max-w-[640px]" role="img" aria-label={`Network connecting ${network.nodes.join(", ")}`}>
              <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full" aria-hidden>
                <circle cx="50" cy="50" r="38" fill="none" stroke="#10275C" strokeOpacity=".12" strokeWidth=".2" />
                {pts.map((p) => <line key={p.label} x1="50" y1="50" x2={p.x} y2={p.y} stroke="#B8913A" strokeWidth=".25" className="draw" />)}
              </svg>
              <div className="absolute left-1/2 top-1/2 flex h-[26%] w-[26%] -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-navy p-2 text-center font-display text-[clamp(.7rem,2.4vw,1.25rem)] leading-tight text-white">{network.center}</div>
              {pts.map((p) => (
                <span key={p.label} style={{ left: `${p.x}%`, top: `${p.y}%` }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 whitespace-nowrap border border-ink/15 bg-paper px-2 py-1 text-[10px] font-semibold sm:px-4 sm:py-2 sm:text-sm">{p.label}</span>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
