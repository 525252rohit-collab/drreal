import { useRef } from "react";
import { gallery } from "../data/content";
import { SectionLabel } from "./Reveal";

export default function Gallery() {
  const rail = useRef<HTMLUListElement>(null);
  const go = (d: number) => rail.current?.scrollBy({ left: d * Math.min(420, window.innerWidth * 0.8), behavior: "smooth" });
  return (
    <section id="moments" className="section bg-white">
      <div className="wrap flex flex-wrap items-end justify-between gap-6">
        <div>
          <SectionLabel n="05" text="MOMENTS FROM THE JOURNEY" />
          <h2 className="h-display max-w-2xl text-[clamp(2.4rem,5.5vw,5rem)]">Moments from the journey.</h2>
        </div>
        <div className="hidden gap-2 sm:flex">
          {[-1, 1].map((d) => (
            <button key={d} onClick={() => go(d)} aria-label={d < 0 ? "Previous photos" : "Next photos"} className="h-12 w-12 border border-ink/25 text-lg transition hover:bg-ink hover:text-white">{d < 0 ? "←" : "→"}</button>
          ))}
        </div>
      </div>
      <ul ref={rail} tabIndex={0} aria-label="Photo gallery, scroll horizontally" className="noscrollbar mt-14 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 sm:px-8 lg:px-12">
        {gallery.map((g, i) => (
          <li key={i} className="relative w-[78vw] max-w-[420px] shrink-0 snap-start">
            <div className="overflow-hidden bg-stone" style={{ aspectRatio: "4 / 5" }}>
              <img src={g.src} alt={g.alt} loading="lazy" width={1000} height={1503} className="h-full w-full object-cover"
                   style={{ objectPosition: g.pos, transform: `scale(${g.zoom})` }} />
            </div>
            <p className="mt-3 text-sm font-semibold">{g.category}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
