import { nav, site } from "../data/content";

export default function Footer() {
  const social: [string, string][] = [["WhatsApp", site.whatsapp], ...Object.entries(site.social)];
  return (
    <footer className="bg-ink pb-8 pt-20 text-white">
      <div className="wrap grid gap-12 md:grid-cols-12">
        <div className="md:col-span-6">
          <p className="text-[13px] font-bold tracking-[0.22em]">DOCTOR REAL ESTATE</p>
          <p className="mt-3 text-sm text-white/60">{site.tagline}</p>
          <img src={site.logo.small} alt={site.logo.alt} loading="lazy" width={80} height={80} className="mt-8 h-20 w-20 rounded-sm bg-white object-contain p-1 opacity-90" />
        </div>
        <nav aria-label="Footer" className="md:col-span-3"><p className="label mb-4 !text-white/50">Navigate</p>
          <ul className="space-y-2 text-sm">{nav.map((l) => <li key={l.id}><a className="text-white/80 hover:text-goldsoft" href={`#${l.id}`}>{l.label}</a></li>)}</ul></nav>
        <div className="md:col-span-3"><p className="label mb-4 !text-white/50">Connect</p>
          <ul className="space-y-2 text-sm">{social.map(([n, h]) => <li key={n}><a className="text-white/80 hover:text-goldsoft" href={h} target="_blank" rel="noopener noreferrer">{n}</a></li>)}</ul></div>
      </div>
      <p className="wrap mt-16 border-t border-white/10 pt-6 text-xs text-white/45">© 2026 Doctor Real Estate. All rights reserved.</p>
    </footer>
  );
}
