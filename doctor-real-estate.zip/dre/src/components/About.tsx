import { about, site } from "../data/content";
import Reveal, { SectionLabel } from "./Reveal";
import Stats from "./Stats";

export default function About() {
  return (
    <section id="about" className="section">
      <div className="wrap">
        <SectionLabel n="01" text="INTRODUCTION" />
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          <Reveal className="lg:col-span-5">
            <div className="overflow-hidden bg-stone" style={{ aspectRatio: "4 / 5" }}>
              <img src={site.photo.small} alt={site.photo.alt} loading="lazy" width={600} height={902} className="h-full w-full object-cover object-top" />
            </div>
          </Reveal>
          <div className="lg:col-span-7 lg:pt-10">
            <Reveal><h2 className="h-display text-[clamp(2.4rem,5.5vw,5rem)]">{about.headline}</h2></Reveal>
            <div className="mt-10 max-w-xl space-y-5 text-lg leading-relaxed text-ink/75">
              {about.body.map((p, i) => <Reveal key={i} delay={i * 80}><p>{p}</p></Reveal>)}
            </div>
            <Reveal><a href="#drivnetwork" className="btn btn-dark mt-10">My Story <span className="arrow">→</span></a></Reveal>
          </div>
        </div>
        <Stats />
      </div>
    </section>
  );
}
