import { testimonials } from "../data/content";
import Reveal from "./Reveal";

export default function Testimonials() {
  return (
    <section id="trust" className="section">
      <div className="wrap">
        <Reveal><h2 className="h-display max-w-3xl text-[clamp(2.4rem,5.5vw,5rem)]">Trusted relationships. Meaningful results.</h2></Reveal>
        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal key={i} delay={i * 80}>
              <figure className="flex h-full flex-col justify-between border border-ink/15 p-8">
                <span className="mb-6 w-fit bg-stone px-2 py-1 text-[10px] font-semibold tracking-wider text-mute">PLACEHOLDER · EDIT IN content.ts</span>
                <blockquote className="font-display text-2xl font-light leading-snug">“{t.quote}”</blockquote>
                <figcaption className="mt-10 text-sm"><strong className="block">{t.name}</strong><span className="text-mute">{t.role}</span></figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
