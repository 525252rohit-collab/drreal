import { drivnetwork, site } from "../data/content";
import Reveal from "./Reveal";

export default function Drivnetwork() {
  return (
    <section id="drivnetwork" className="section bg-white">
      <div className="wrap grid items-center gap-14 lg:grid-cols-2">
        <Reveal>
          <div className="mx-auto flex aspect-square w-full max-w-[520px] items-center justify-center border border-stone bg-white p-6 md:p-10">
            <img src={site.logo.src} alt={site.logo.alt} loading="lazy" width={900} height={900} className="h-full w-full object-contain" />
          </div>
        </Reveal>
        <div>
          <Reveal><p className="label mb-6">Drivnetwork</p><h2 className="h-display text-[clamp(2.4rem,5vw,4.5rem)]">{drivnetwork.headline}</h2></Reveal>
          <div className="mt-8 max-w-lg space-y-5 text-lg leading-relaxed text-ink/75">
            {drivnetwork.body.map((p, i) => <Reveal key={i} delay={i * 80}><p>{p}</p></Reveal>)}
          </div>
          <Reveal><a href={drivnetwork.cta.href} className="btn btn-dark mt-10">{drivnetwork.cta.label} <span className="arrow">→</span></a></Reveal>
        </div>
      </div>
    </section>
  );
}
