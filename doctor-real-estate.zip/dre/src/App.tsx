import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Services from "./components/Services";
import Philosophy from "./components/Philosophy";
import Network from "./components/Network";
import Gallery from "./components/Gallery";
import Testimonials from "./components/Testimonials";
import Drivnetwork from "./components/Drivnetwork";
import CTA from "./components/CTA";
import Footer from "./components/Footer";

export default function App() {
  return (
    <>
      <a href="#about" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:bg-gold focus:px-4 focus:py-2">Skip to content</a>
      <Navbar />
      <main>
        <Hero /><About /><Services /><Philosophy /><Network /><Gallery /><Testimonials /><Drivnetwork /><CTA />
      </main>
      <Footer />
    </>
  );
}
